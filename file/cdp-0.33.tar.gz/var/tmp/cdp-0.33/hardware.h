/*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*
 * hardware.h -
 *     Hardware CD status & commands.
\*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*/

#ifndef  __HARDWARE__H
#define  __HARDWARE__H


extern char                   *cd_device; 
#define CDNULL 0
#define CDPLAY 1
#define CDPAUZ 3
#define CDSTOP 4
#define CDEJECT 5


typedef struct {
    int              cur_track;
    int              cur_index;
    int              cur_lasttrack;
    int              cur_firsttrack;
    int              cur_pos_abs;
    int              cur_frame;
    int              cur_pos_rel;
    int              cur_tracklen;
    int              cur_cdlen;
    int              cur_ntracks;
    int              cur_nsections;
    int              cur_cdmode;
    int              cur_listno;
    int              cur_stopmode;
    int              cur_balance;
    char           * cur_artist;
    char           * cur_cdname;
    char           * cur_trackname;
    char             cur_contd;
    char             cur_avoid;
    struct play    * playlist;
    struct cdinfo    thiscd; /* , * cd; */
    int              cd_fd;
    BOOL             fTOCRead;
} cdStatusType;


void    cd_init( cdStatusType       * pStatus );
int     cd_status( cdStatusType     * pStatus );
int     cd_eject( cdStatusType     * pStatus );
void    cd_play( cdStatusType     * pStatus,
		 int   start, int    pos, int    end );
void    cd_pause( cdStatusType     * pStatus );
void    cd_stop( cdStatusType     * pStatus );

/*
void   play_cd( int start, int pos, int end) ;
int    eject_cd( void );
int    cd_status( void );
void   pause_cd( void );
void   stop_cd( void );
*/

#else   /* __HARDWARE__H */
#error  Header file hardware.h included twice
#endif  /* __HARDWARE__H */

/*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*
 *     
 * hardware.h - End of File
\*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*/
