/*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*
 * hardware.c       1.12    12/17/92
 *
 * Get information about a CD.
\*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*/

#include  <errno.h>
#include  <stdio.h>
#include  <stdlib.h>
#include  <string.h>
#include  <unistd.h>
#include  <sys/types.h>
#include  <sys/ioctl.h>
#include  <fcntl.h>
#include  <sys/param.h>
#include  <sys/stat.h>
#include  <sys/time.h>
#ifdef linux
#  include  <linux/cdrom.h>
#else
#  include  <sundev/srreg.h>
#endif                  /* linux */
#include  <ncurses.h>

#include  "struct.h"
#include  "misc.h"
#include  "hardware.h"
#include  "display.h"


/*
void                   *malloc ();
char                   *strchr ();

int                     pStatus->cd_fd = -1;
 */

/*
 * The minimum volume setting for the Sun and DEC CD-ROMs is 128 but for other
 * machines this might not be the case.
 */
int                     min_volume = 128;
int                     max_volume = 255;

#ifdef linux
char                   *cd_device = "/dev/cdrom\0"; 
#else
char                   *cd_device = "/dev/rsr0\0";
#endif


GLOBAL void    cd_init( cdStatusType       * pStatus )
{
    memset( pStatus, 0, sizeof( cdStatusType ) );
    pStatus->cd_fd = -1;
    pStatus->cur_index = 0;  /* Current index mark */
    pStatus->playlist = NULL;
    pStatus->cur_track = -1;
    pStatus->cur_balance = 10;
}


/*
 * read_toc( pStatus )
 *
 * Read the table of contents from the CD.  Return a pointer to a cdinfo
 * struct containing the relevant information (minus artist/cdname/etc.)
 * This is a static struct.  Returns NULL if there was an error.
 *
 * XXX allocates one trackinfo too many.
 */
static int               read_toc( cdStatusType     * pStatus )
{
    struct playlist        *l;
    struct cdrom_tochdr     hdr;
    struct cdrom_tocentry   entry;
    int                     i,
                            pos;

    if (pStatus->cd_fd < 0)
        return( -1 );

    if (ioctl (pStatus->cd_fd, CDROMREADTOCHDR, &hdr)) {
        perror ("readtochdr");
        return( -1 );
    }
    pStatus->thiscd.artist[0] = pStatus->thiscd.cdname[0] = '\0';
    pStatus->thiscd.whichdb = pStatus->thiscd.otherrc = pStatus->thiscd.otherdb = NULL;
    pStatus->thiscd.length = 0;
    pStatus->thiscd.autoplay = pStatus->thiscd.playmode = pStatus->thiscd.volume = 0;
    pStatus->thiscd.ntracks = hdr.cdth_trk1;

    if (pStatus->thiscd.lists != NULL) {
        for (l = pStatus->thiscd.lists; l->name != NULL; l++) {
            free (l->name);
            free (l->list);
        }
        free (pStatus->thiscd.lists);
        pStatus->thiscd.lists = NULL;
    }
    if (pStatus->thiscd.trk != NULL)
        free (pStatus->thiscd.trk);

    pStatus->thiscd.trk = malloc ((pStatus->thiscd.ntracks + 1) *
				  sizeof (struct trackinfo));

    if (pStatus->thiscd.trk == NULL) {
        perror ("malloc");
        return( -1 );
    }
    for (i = 0; i <= pStatus->thiscd.ntracks; i++) {
        if (i == pStatus->thiscd.ntracks)
            entry.cdte_track = CDROM_LEADOUT;
        else
            entry.cdte_track = i + 1;
        entry.cdte_format = CDROM_MSF;
        if (ioctl (pStatus->cd_fd, CDROMREADTOCENTRY, &entry)) {
            perror ("tocentry read");
            return( -1 );
        }
        pStatus->thiscd.trk[i].data =
            pStatus->thiscd.trk[i].avoid = entry.cdte_ctrl & CDROM_DATA_TRACK ?
            1 : 0;
        pStatus->thiscd.trk[i].length = entry.cdte_addr.msf.minute * 60 +
            entry.cdte_addr.msf.second;
        pStatus->thiscd.trk[i].start = pStatus->thiscd.trk[i].length * 75 +
            entry.cdte_addr.msf.frame;
        pStatus->thiscd.trk[i].songname = pStatus->thiscd.trk[i].otherrc =
            pStatus->thiscd.trk[i].otherdb = NULL;
        pStatus->thiscd.trk[i].contd = 0;
        pStatus->thiscd.trk[i].volume = 0;
        pStatus->thiscd.trk[i].track = i + 1;
        pStatus->thiscd.trk[i].section = 0;
    }

    /* Now compute actual track lengths. */
    pos = pStatus->thiscd.trk[0].length;

    for (i = 0; i < pStatus->thiscd.ntracks; i++) {
        pStatus->thiscd.trk[i].length = pStatus->thiscd.trk[i + 1].length - pos;
        pos = pStatus->thiscd.trk[i + 1].length;
        if (pStatus->thiscd.trk[i].data)
            pStatus->thiscd.trk[i].length = (pStatus->thiscd.trk[i + 1].start -
                                    pStatus->thiscd.trk[i].start) * 2;
        if (pStatus->thiscd.trk[i].avoid)
            strmcpy (&pStatus->thiscd.trk[i].songname, "DATA TRACK");
    }

    pStatus->thiscd.length = pStatus->thiscd.trk[pStatus->thiscd.ntracks].length;
    pStatus->fTOCRead = TRUE;

    return  0;
}


/*----------------------------------------------------------------------
 * cd_status( pStatus )
 *
 * Return values:
 *
 *      0       No CD in drive.
 *      1       CD in drive.
 *      2       CD has just been inserted (TOC has been read)
 *      3       CD has just been removed
 *
 * Updates pStatus->cur_track, pStatus->cur_pos_rel, 
 *         pStatus->cur_pos_abs and other variables.
\*----------------------------------------------------------------------*/
GLOBAL int     cd_status( cdStatusType     * pStatus )
{
    char                    realname[MAXPATHLEN];
    static int              warned = 0;
    struct cdrom_subchnl    sc;
    int                     ret = 1;

    if (pStatus->cd_fd < 0) {
        if ((pStatus->cd_fd = open (cd_device, O_RDONLY )) < 0) {
            if (errno == EACCES) {
                if (!warned) {
		    displayClearScreen( NULL );
                    strcpy (realname, cd_device);
		    resetty();
		    resetterm();
                    fprintf (stderr,
                        "As root, please run\n\nchmod 666 %s\n\n%s\n", realname,
                        "to give yourself permission to access the CD-ROM device.");
                    warned++;
		    myExit( -1 );
                }
            } else if (errno != ENXIO) {
                perror (cd_device);
                if (pStatus->thiscd.trk != NULL)
                    free (pStatus->thiscd.trk);
                myExit (1);
            }
            return (0);
        }
        pStatus->cur_cdmode = 5;
    }
    if (warned) {
        warned = 0;
        fprintf (stderr, "Thank you.\n");
	myExit( -1 );
    }
    sc.cdsc_format = CDROM_MSF;

    if (ioctl (pStatus->cd_fd, CDROMSUBCHNL, &sc)) {
        pStatus->cur_cdmode = 5;
        pStatus->cur_track = -1;
        pStatus->cur_cdlen = pStatus->cur_tracklen = 1;
        pStatus->cur_pos_abs = pStatus->cur_pos_rel = pStatus->cur_frame = 0;
        return (0);
    }
    if (pStatus->cur_cdmode == 5) {      /* CD has been ejected */
        pStatus->cur_pos_rel = pStatus->cur_pos_abs = pStatus->cur_frame = 0;

        if ( read_toc( pStatus ) < 0 ) {
            close (pStatus->cd_fd);
            pStatus->cd_fd = -1;
	    return (0);
        }
        pStatus->cur_nsections = 0;
        pStatus->cur_ntracks = pStatus->thiscd.ntracks;
        pStatus->cur_cdlen = pStatus->thiscd.length;
        /* load (); */
        pStatus->cur_artist = pStatus->thiscd.artist;
        pStatus->cur_cdname = pStatus->thiscd.cdname;
        pStatus->cur_cdmode = 4;
        ret = 2;
    }
    switch (sc.cdsc_audiostatus) {
        case CDROM_AUDIO_PLAY:
            pStatus->cur_cdmode = 1;
          dopos:
            pStatus->cur_pos_abs = sc.cdsc_absaddr.msf.minute * 60 +
                sc.cdsc_absaddr.msf.second;
            pStatus->cur_frame = pStatus->cur_pos_abs * 75 + 
	                            sc.cdsc_absaddr.msf.frame;

            /* Only look up the current track number if necessary. */
            if  ( pStatus->cur_track < 1 
		  || pStatus->cur_frame < 
                            pStatus->thiscd.trk[pStatus->cur_track - 1].start 
		  || pStatus->cur_frame >= 
		      (pStatus->cur_track >= pStatus->cur_ntracks ?
                           (pStatus->cur_cdlen + 1) * 75 :
		             pStatus->thiscd.trk[pStatus->cur_track].start)) {
                pStatus->cur_track = 0;
                while (pStatus->cur_track < pStatus->cur_ntracks && pStatus->cur_frame >=
                       pStatus->thiscd.trk[pStatus->cur_track].start)
                    pStatus->cur_track++;
            }
            if ( pStatus->cur_track >= 1 && sc.cdsc_trk > 
		 pStatus->thiscd.trk[pStatus->cur_track - 1].track)
                pStatus->cur_track++;
            pStatus->cur_index = sc.cdsc_ind;
doall:
            if  ( pStatus->cur_track >= 1 
		  &&  pStatus->cur_track <= pStatus->cur_ntracks) {
                pStatus->cur_trackname = 
                      pStatus->thiscd.trk[pStatus->cur_track - 1].songname;
                pStatus->cur_avoid = pStatus->thiscd.trk[ pStatus->cur_track - 1 ].avoid;
                pStatus->cur_contd = pStatus->thiscd.trk[pStatus->cur_track - 1].contd;
                pStatus->cur_pos_rel = (pStatus->cur_frame -
                               pStatus->thiscd.trk[pStatus->cur_track - 1].start) / 75;
                if (pStatus->cur_pos_rel < 0)
                    pStatus->cur_pos_rel = -pStatus->cur_pos_rel;
            }
            /* note: workbone requires playlist == NULL always! */
            if  ( pStatus->playlist != NULL  &&  pStatus->playlist[0].start) {
                pStatus->cur_pos_abs -= pStatus->thiscd.trk[ pStatus->playlist[
			      pStatus->cur_listno - 1].
                                       start - 1].start / 75;
                pStatus->cur_pos_abs += pStatus->playlist[pStatus->cur_listno - 1].starttime;
            }
            if (pStatus->cur_pos_abs < 0)
                pStatus->cur_pos_abs = pStatus->cur_frame = 0;

            if (pStatus->cur_track < 1)
                pStatus->cur_tracklen = pStatus->thiscd.length;
            else
                pStatus->cur_tracklen = pStatus->thiscd.trk[pStatus->cur_track - 1].length;
            break;

        case CDROM_AUDIO_PAUSED:
            if (pStatus->cur_cdmode == 1 || pStatus->cur_cdmode == 3) {
                pStatus->cur_cdmode = 3;
                goto dopos;
            } else
                pStatus->cur_cdmode = 4;
            goto doall;

        case CDROM_AUDIO_COMPLETED:
            pStatus->cur_cdmode = 0;     /* waiting for next track. */
            break;

        case CDROM_AUDIO_NO_STATUS:
            pStatus->cur_cdmode = 4;
            pStatus->cur_lasttrack = pStatus->cur_firsttrack = -1;
            goto doall;
    }
    return (ret);
}


/*
 * cd_pause( pStatus )
 *
 * Pause the CD, if it's in play mode.  If it's already paused, go back to
 * play mode.
 */
GLOBAL void   cd_pause( cdStatusType     * pStatus )
{
    if (pStatus->cd_fd < 0)              /* do nothing if there's no CD! */
        return;

    switch (pStatus->cur_cdmode) {
        case 1:         /* playing */
            pStatus->cur_cdmode = 3;
            ioctl (pStatus->cd_fd, CDROMPAUSE);
            break;
        case 3:         /* paused */
            pStatus->cur_cdmode = 1;
            ioctl (pStatus->cd_fd, CDROMRESUME);
    }
}

/*
 * cd_stop( pStatus )
 *
 * Stop the CD if it's not already stopped.
 */
GLOBAL void        cd_stop( cdStatusType     * pStatus )
{
    if  ( pStatus->cd_fd < 0 )
        return;

    if (pStatus->cur_cdmode != 4) {
        pStatus->cur_lasttrack = pStatus->cur_firsttrack = -1;
        pStatus->cur_cdmode = 4;
        ioctl (pStatus->cd_fd, CDROMSTOP);
        pStatus->cur_track = 1;
    }
}


/*
 * play_chunk( pStatus, start, end)
 *
 * Play the CD from one position to another (both in frames.)
 */
static void    play_chunk(  cdStatusType     * pStatus, int   start, int     end )
{
    struct cdrom_msf        msf;

    if  ( ! pStatus->fTOCRead  ||  pStatus->cd_fd < 0 )
        return;

    end--;
    if (start >= end)
        start = end - 1;

    msf.cdmsf_min0 = start / (60 * 75);
    msf.cdmsf_sec0 = (start % (60 * 75)) / 75;
    msf.cdmsf_frame0 = start % 75;
    msf.cdmsf_min1 = end / (60 * 75);
    msf.cdmsf_sec1 = (end % (60 * 75)) / 75;
    msf.cdmsf_frame1 = end % 75;

    if (ioctl( pStatus->cd_fd, CDROMSTART ) ) {
        perror ("CDROMSTART");
        return;
    }
    if (ioctl (pStatus->cd_fd, CDROMPLAYMSF, &msf)) {
        printf ("play(%d,%d)\n", start, end);
        printf ("msf = %d:%d:%d %d:%d:%d\n",
                msf.cdmsf_min0, msf.cdmsf_sec0, msf.cdmsf_frame0,
                msf.cdmsf_min1, msf.cdmsf_sec1, msf.cdmsf_frame1);
        perror ("CDROMPLAYMSF");
        return;
    }
}


/*
 * cd_play(starttrack, pos, endtrack)
 *
 * Start playing the CD or jump to a new position.  "pos" is in seconds,
 * relative to start of track.
 */
GLOBAL void    cd_play( cdStatusType     * pStatus,
		        int    start, int    pos, int    end )
{

    if  ( ! pStatus->fTOCRead  ||  pStatus->cd_fd < 0 )
        return;

    pStatus->cur_firsttrack = start;
    start--;
    end--;
    pStatus->cur_lasttrack = end;

    play_chunk( pStatus, pStatus->thiscd.trk[start].start + pos * 75,
	        end >= pStatus->cur_ntracks ?
                pStatus->cur_cdlen * 75 : pStatus->thiscd.trk[end].start - 1);
}


/*
 * Eject the current CD, if there is one, and set the mode to 5.
 *
 * Returns 0 on success, 1 if the CD couldn't be ejected, or 2 if the
 * CD contains a mounted filesystem.
 */
GLOBAL int     cd_eject( cdStatusType     * pStatus )
{
    struct stat             stbuf;
    struct ustat            ust;

    if (pStatus->cur_cdmode == 5)        /* Already ejected! */
        return (0);

    if (fstat (pStatus->cd_fd, &stbuf) != 0) {
        perror ("fstat");
        return (1);
    }
    /* Is this a mounted filesystem? */
    if (ustat (stbuf.st_rdev, &ust) == 0)
        return (2);

    if (ioctl (pStatus->cd_fd, CDROMEJECT)) {
        perror ("CDEJECT");
        return (1);
    }
    pStatus->cur_track = -1;
    pStatus->cur_cdlen = pStatus->cur_tracklen = 1;
    pStatus->cur_pos_abs = pStatus->cur_pos_rel = pStatus->cur_frame = 0;
    pStatus->cur_cdmode = 5;

    return (0);
}


/*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*
 *
 * hardware.c - end of file
\*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*/
