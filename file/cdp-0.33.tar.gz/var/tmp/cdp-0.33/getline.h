/*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*
 * getline.h -
 *     
\*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*/

#ifndef  __getline__H
#define  __getline__H


int     getline( int      y, 
		 int      x,
		 int      width,
 		 chtype   attrText,
		 chtype   attrDefault,
		 chtype   attrMarkers,
		 char   * str,
		 int      strSize,
		 char   * lpszDef );

#define   GETLINE_OK       0 
#define   GETLINE_ERR     -1
#define   GETLINE_CANCEL   1

#define   ENTER            0x0a


#else   /* __getline__H */
#error  Header file getline.h included twice
#endif  /* __getline__H */

/*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*
 *     
 * getline.h - End of File
\*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*/
