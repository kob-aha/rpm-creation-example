/*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*
 * cdp.h -
 *   CDP CD ROM Player 
 *
 *   Copyright (C) 1994  Sariel Har-Peled
 *
 *   Based on WorkBone CD Rom Player Software
 *            Copyright (C) 1993  Thomas McWilliams 
 * 
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2, or (at your option)
 *   any later version.
 *   
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *   
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *     
\*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*/

#ifndef  __CDP__H
#define  __CDP__H

#define  VERSION      "0.33"


/*======================================================================
 * CD Player mode structure
\*======================================================================*/
typedef  struct {
    BOOL                     fSilentMode;
    BOOL                     fNoAutoPlay;
    BOOL                     fCDPlayMode;
    BOOL                     fCmdTable, fNoFastIn, fCmdVersion;
    BOOL                     fNoVolumeMixer;
    int                      startTrack;
}  modeInfoType;



#else   /* __CDP__H */
#error  Header file cdp.h included twice
#endif  /* __CDP__H */

/*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*
 *     
 * cdpa.h - End of File
\*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*/









