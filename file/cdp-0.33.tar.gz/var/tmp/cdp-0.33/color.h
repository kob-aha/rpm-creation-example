#ifndef  __COLOR__H
#define  __COLOR__H

void init_colors ();
extern int hascolors;
extern int disable_colors;

#define NORMAL_COLOR   (hascolors?COLOR_PAIR (1): 0)
#define SELECTED_COLOR (hascolors?COLOR_PAIR (2):A_REVERSE)
#define MARKED_COLOR   (hascolors?COLOR_PAIR (3):A_BOLD)
#define MARKED_SELECTED_COLOR (hascolors?COLOR_PAIR (4):A_REVERSE | A_BOLD)
#define ERROR_COLOR (hascolors?COLOR_PAIR (5):0)
#define MENU_ENTRY_COLOR (hascolors?COLOR_PAIR (6)|A_BOLD:A_REVERSE)
#define REVERSE_COLOR (hascolors?COLOR_PAIR(7):A_REVERSE)
#define INPUT_COLOR (hascolors?COLOR_PAIR(2):0)
#define Q_SELECTED_COLOR (hascolors?SELECTED_COLOR: 0)
#define Q_UNSELECTED_COLOR (hascolors?A_REVERSE: A_REVERSE)

extern int sel_mark_color [4];

#endif  /* __COLOR__H */
