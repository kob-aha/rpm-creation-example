/*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*
 *  CDPlay  0.33
 *           Copyright (C) 1994, 1995    Sariel Har-Peled
 *
 *  Based on WorkBone CD Rom Player Software
 *           Copyright (C) 1993  Thomas McWilliams
 *  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2, or (at your option)
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
\*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*/

#include  <stdlib.h>
#include  <stdio.h>
#include  <stdarg.h>
#include  <sys/types.h>
#include  <sys/time.h>
#include  <signal.h>
#include  <unistd.h>
#include  <termios.h>
#include  <mntent.h>
#include  <getopt.h>
#include  <string.h>
#include  <ncurses.h>

#include  "struct.h"
#include  "misc.h"
#include  "cdp.h"
#include  "color.h"
#include  "getline.h"
#include  "hardware.h"
#include  "display.h"
#include  "database.h"


/*======================================================================
 * Prototypes
\*======================================================================*/
static void             playtime( char    * str );


/*======================================================================
 * Variables
\*======================================================================*/
#ifdef  bbbb
char                   *cur_trackname;  /* Take a guess */
int                     cur_index = 0;  /* Current index mark */
int                     cur_frame;      /* Current frame number */
struct play            *playlist = NULL;
struct cdinfo           thiscd, oldcd, *cd = &thiscd;
int                     cur_track = -1; /* Current track number, starting at 1 */
char                   *cur_artist;     /* Name of current CD's artist */
char                    cur_avoid;      /* Avoid flag */
char                    cur_contd;      /* Continued flag */
char                   *cur_cdname;     /* Album name */
int                     cur_nsections;  /* Number of sections currently defined */
int                     exit_on_eject = 0;

int                     cur_balance = 10,
                        info_modified;
int                     cur_track,
                        cur_pos_abs,
                        cur_pos_rel,
                        cur_tracklen,
                        cur_cdlen,
                        cur_cdmode,
                        cur_ntracks,
                        cur_lasttrack,
                        cur_firsttrack,
                        cur_listno;
#endif  /* bbbb */

static cdStatusType     cdStatus;
static displayInfoType  dispInfo;
struct cdinfo           oldcd;

/*======================================================================
 * Start Of Code
\*======================================================================*/


static  void     dispScreen( modeInfoType      * pMode )
{
    /* to update current track information */
    cd_status( &cdStatus );
    
    dispInfo.cur_track = cdStatus.cur_track;
    dispInfo.fSilentMode = pMode->fSilentMode;
    if  ( ! dispInfo.fNoFollowMode ) 
        dispInfo.view_track = cdStatus.cur_track;
    if  ( memcmp( &oldcd, &cdStatus.thiscd, sizeof( oldcd ) ) != 0 ) {
 /*                   displayStatusPrintf( &dispInfo,  "loading....." );
  */   
 /* printf( "loading......\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" );
        */
	load( &cdStatus ); 
        memcpy( &oldcd, &cdStatus.thiscd, sizeof( oldcd ) );
    }
    displayControlPanel( &dispInfo );
}


static  void    printHelpMessage( void )
{
    printf( "\nCDPlay version %s     Copyright 1994 (c) Sariel Har-Peled\n",
            VERSION );
    printf(   "      Based on WorkBone Copyright 1993 (c) Thomas McWilliams\n" );
    printf(   "Free Software under GNU General Public License.\n\n" );
    printf(   "Useage:  cdp [ -c <device> -h | -l | -s | -n ] [play <track-num>]\n" 
               );
    printf(   "         cdplay [ -c <device> -h | -l | -n ]"
                                 " [play <track-num>] [stop] [table]\n" );
    printf(   "           -c : play on device\n" );
    printf(   "           -h : help\n" );
    printf(   "           -n : do NOT auto play\n" );
    printf(   "           -l : slow start (wait for init)\n" );
    printf(   "           -m : Turn off volume control\n" );
    printf(   "           -s : Silent Mode\n\n" );
    printf(   "Type 'cdp' to start program.\n\n" );
    printf(   "Engage the NUM LOCK on your keypad. From inside CD Play\n" );
    printf(   "pressing DEL on numeric keypad will display a help menu.\n\n" );
    printf(   "'cdplay' is the non-interactive version of the program.\n\n" );
    myExit( 0 );
}


static void          printTOC( void )
{
    int                  ind;
    struct trackinfo   * trk;
    char                 buffer[ 200 ], ch;
 
    load( &cdStatus ); 
    printf( "\nArtist : %s\n", cdStatus.thiscd.artist );
    printf( "CD Name: %s\n", cdStatus.thiscd.cdname );
    printf( "Tracks Number: %3d   Total Play Time: %2d:%02d:%02d\n",
              cdStatus.thiscd.ntracks, 
              cdStatus.thiscd.length / 3600, 
              (cdStatus.thiscd.length / 60) % 60,
              cdStatus.thiscd.length % 60 );

    printf( "Track Num  Start Time  Length  Name \n" );
    for  ( ind = 0; ind < cdStatus.thiscd.ntracks; ind++ ) {
        trk = &cdStatus.thiscd.trk[ ind ];
        if  ( trk->songname != NULL ) {
            sprintf( buffer, "%s", trk->songname );
        } else
            buffer[ 0 ] = 0;

        ch = ( (ind + 1 ) == cdStatus.cur_track )? '*' : ' ';
        printf( 
           " %c %2d     %2d:%02d:%02d    %2d:%02d    %s\n",
           ch,
           ind + 1, trk->start / (60 * 75 * 60), trk->start / (60 *75) % 60,
           ( trk->start / 75 ) % 60,
           trk->length / 60, trk->length % 60,
           &buffer[0] );
    }
}


static  void        dispStatus( int      * pSaveTrack )
{
    char                    szTotalTime[ 100 ];

    switch  ( cdStatus.cur_cdmode ) {
        case  0 :             /* CDNULL */
            cdStatus.cur_track = *pSaveTrack = 1;
            displayStatusPrintf( &dispInfo,  "stopped " );
            break;

        case  1 :             /* CDPLAY */
            playtime( szTotalTime );
            displayStatusPrintf( &dispInfo,  "playing #~%d~%s ", 
                                cdStatus.cur_track,
                                szTotalTime );
            break;

        case  3 :             /* CDPAUZ */
            displayStatusPrintf( &dispInfo,  "pause   #%d ", cdStatus.cur_track );
            break;

        case  4 :             /* CDSTOP */
            displayStatusPrintf( &dispInfo,  "stopped #%d ", *pSaveTrack );
            break;

        case  5 :             /* CDEJECT */
            return;

        default :
            displayStatusPrintf( &dispInfo, "cdStatus.cur_cdmode %d ",
                                 cdStatus.cur_cdmode);
            break;
    } /* switch */
}


static  void     flipFollowMode( void )
{
    dispInfo.fNoFollowMode = ! dispInfo.fNoFollowMode;
    if  ( ! dispInfo.fNoFollowMode   &&  cdStatus.cur_track != dispInfo.view_track ) {
        cd_play( &cdStatus, dispInfo.view_track, 0, cdStatus.cur_ntracks + 1);
    }
}


static inline int     normalizeTrackNum( int     trk )
{
    if  ( trk > cdStatus.cur_ntracks )
        trk = 1;
    if  ( trk < 1 )
        trk = cdStatus.cur_ntracks;

    return   trk;
}


static void       handleTrackMoveKey( displayInfoType      * pInfo,
                                      int                    delta )
{
    if  ( pInfo->fNoFollowMode ) {
        pInfo->view_track = normalizeTrackNum( pInfo->view_track + delta );
    } else {
        cd_play( &cdStatus, normalizeTrackNum( cdStatus.cur_track + delta ), 0,
                 cdStatus.cur_ntracks + 1);
    }
}


static  void     doPlayLoop( modeInfoType      * pMode )
{
/*    static int              count = 0; */
    struct timeval          mydelay;
    fd_set                  rset;
    int                     sel_stat, cdStat;
    int                     key = 0, oldTrack = -1, oldViewTrack = -1;
    BOOL                    fOldNoFollowMode = FALSE;
    int                     oldcur_cdmode = -1;
    int                     save_track = 1, tmppos = 0;

    do {
        mydelay.tv_sec = 1;
        mydelay.tv_usec = 200;

        cdStat = cd_status( &cdStatus );
        dispStatus( &save_track );
        if  ( cdStatus.cur_cdmode != oldcur_cdmode  
              ||  cdStatus.cur_track != oldTrack  
              ||  dispInfo.view_track != oldViewTrack  
              ||  dispInfo.fNoFollowMode != fOldNoFollowMode ) {
            oldcur_cdmode = cdStatus.cur_cdmode;
            oldViewTrack = dispInfo.view_track;
            oldTrack = cdStatus.cur_track;
            fOldNoFollowMode = dispInfo.fNoFollowMode;
            dispScreen( pMode );
        }           

        /*
         * use select() to update status every 200 millisecs or
         * sooner if keypad has data
         */
        FD_ZERO (&rset);
        FD_SET (STDIN_FILENO, &rset);
        sel_stat = select( 4, &rset, NULL, NULL, 
                           pMode->fSilentMode? NULL : &mydelay);
        if  ( cdStat == 0  ||  cdStat == 4  ||  cdStatus.cur_cdmode == CDEJECT) 
            return;
        if (cdStatus.cur_cdmode < 1)
            save_track = 1;

        /* if key was pressed, parse it and do function */
        if (FD_ISSET (STDIN_FILENO, &rset)) {
            key = getch();
            switch   ( key ) {
                case  '.' :
                case  '?' :
                    break;
                    
                case   ENTER :
                    dispInfo.cur_track = cdStatus.cur_track;
                    displayEditCurrSongName( &cdStatus, &dispInfo );
                    break;

                case  'a' :
                case  'A' :                 
                    dispInfo.cur_track = cdStatus.cur_track;
                    displayEditArtistName( &cdStatus, &dispInfo );
                    break;

                case  'c' :
                case  'C' :                 
                    dispInfo.cur_track = cdStatus.cur_track;
                    displayEditCDName( &cdStatus, &dispInfo );
                    break;

                case  'r' :
                case  'R' :
                    displayClearScreen( &dispInfo );
                    dispScreen( pMode );
                    break;

                case  '1' :
                    if (cdStatus.cur_cdmode == CDPLAY) {
                        tmppos = cdStatus.cur_pos_rel - 15;
                        cd_play( &cdStatus, cdStatus.cur_track, tmppos > 0 ? 
                                   tmppos : 0, cdStatus.cur_ntracks + 1);
                    }
                    break;

                case  '3' :
                    if (cdStatus.cur_cdmode == CDPLAY) {
                        tmppos = cdStatus.cur_pos_rel + 15;
                        if  ( tmppos < cdStatus.thiscd.trk[ 
                                          cdStatus.cur_track - 1 ].length )
                            cd_play( &cdStatus, cdStatus.cur_track, tmppos, 
                                     cdStatus.cur_ntracks + 1 );
                    }
                    break;

                case  '2' :
                case  KEY_DOWN :
                    cd_stop( &cdStatus );
                    cd_eject( &cdStatus );
                    break;

                case  '4' :
                case  KEY_LEFT :
                    handleTrackMoveKey( &dispInfo, -1 );
                    break;

                case '5':
                    if (cdStatus.cur_cdmode == CDPLAY)
                        cd_play( &cdStatus, cdStatus.cur_track, 0, 
                                 cdStatus.cur_ntracks + 1);
                    break;

                case  '6':
                case  KEY_RIGHT :
                    handleTrackMoveKey( &dispInfo, +1 );
                    break;

                case '7':
                    displayStatusPrintf( &dispInfo,  "stop ");
                    save_track = cdStatus.cur_track;
                    cd_stop( &cdStatus );
                    break;

                case  '8' :
                case  KEY_UP :
                    if  ( cdStatus.cur_cdmode == CDPLAY  
                          ||  cdStatus.cur_cdmode == CDPAUZ ) {
                        cd_pause( &cdStatus );
                    }
                    break;

                case '9':
                    if ( cdStatus.cur_cdmode == CDSTOP 
                         ||  cdStatus.cur_cdmode == CDNULL) {
                        cd_play( &cdStatus, save_track, 0, cdStatus.cur_ntracks + 1);
                    }
                    break;

                case 0x1b:
                    getch();
                    getch();
                    displayStatusPrintf( &dispInfo,  "Turn ON Num Lock! " );
                    sleep (1);
                    break;

                case 's' :
                case 'S' :
                    pMode->fSilentMode = ! pMode->fSilentMode;
                    dispScreen( pMode );
                    break;

                case  'F' :
                case  'f' :
                    flipFollowMode();
                    break;

                case 'q' :
                case 'Q' :
                default:
                    break;
            }
        }
    }  while  ( key != 'q'  &&  key != 'Q' );
    displayTTYResetColor( &dispInfo );
}


static void             playtime( char    * str )
{
    int                     mymin, emin;
    int                     mysec, esec;

    mysec = cdStatus.cur_pos_rel % 60;
    mymin = cdStatus.cur_pos_rel / 60;
    esec = cdStatus.cur_pos_abs % 60;
    emin = cdStatus.cur_pos_abs / 60;
    if  ( emin >= 60 ) 
        sprintf( str, "%s ~%2d~:~%02d~  ~%d~:~%02d~:~%02d~",
                 cdStatus.cur_track > 9 ? " " : "  ",
                 mymin, mysec, emin / 60, emin % 60, esec );
    else
        sprintf( str, "%s ~%2d~:~%02d~  ~%2d~:~%02d~", cdStatus.cur_track > 9 ? " " : "  ",
             mymin, mysec, emin, esec );
}
 

static  void        checkCDMounted( void )
{
    FILE                   * fp;
    struct mntent          * mnt;
    
    /* check if drive is mounted (from Mark Buckaway's cdplayer code) */
    if  ( ( fp = setmntent (MOUNTED, "r")) == NULL) {
        fprintf(stderr, "Couldn't open %s: %s\n", MOUNTED, strerror (errno));
        myExit (1);
    }

    while ((mnt = getmntent (fp)) != NULL) {
/*        printf( "mounted: %s\n", mnt->mnt_fsname );*/
        if (strcmp (mnt->mnt_type, "iso9660") == 0) {
            if  ( strcmp( cd_device, mnt->mnt_fsname ) == 0 ) { 
                fputs ("CDROM already mounted. Operation aborted.\n", stderr);
                endmntent (fp);
                myExit (1);
            }
        }
    }
    endmntent (fp);
}


static BOOL         isNumeric( char      * str ) 
{
    if  ( str == NULL )
        return  FALSE;
    while  ( *str ) {
        if  ( *str < '0'  ||  *str > '9' )
            return   FALSE;
        str++;
    }

    return   TRUE;
}


static void         readCommandLine( int    argc, char     * argv[ ], 
                              modeInfoType      * pInfoMode )
{
    char                   * str, *strNext, * pos;
    int                      ind;

    memset( pInfoMode, 0, sizeof( modeInfoType ) );

    str = argv[ 0 ];
    pos = strrchr( argv[ 0 ], '/' );
    if ( pos != NULL )
       str = pos + 1;    

    if  ( strcmp( str, "cdplay" ) == 0 ) {
        pInfoMode->fCmdVersion = TRUE;
        pInfoMode->fCDPlayMode = TRUE;
    }

    /* get options */
    for (ind = 1; ind < argc; ind++ ) {
        str = argv[ ind ];
        if  ( ind < argc - 1 ) 
            strNext = argv[ ind + 1 ];
        else
            strNext = NULL;
        if  ( str[ 0 ] == '-'  &&  str[ 1 ]  &&  ! str[ 2 ] ) {
            switch  ( str[ 1 ] ) {
                case  'c' : 
                    ind++;
                    if  ( strNext != NULL ) 
                        cd_device = strNext;
                    break;

                case  'l' :
                    pInfoMode->fNoFastIn = TRUE;
                    break;
 
                case  'm' :
                    pInfoMode->fNoVolumeMixer = TRUE;
                    break;

                case  's' :
                    pInfoMode->fSilentMode = TRUE;
                    break;

                case  'n' :
                    pInfoMode->fNoAutoPlay = TRUE;
                    break;

                default:
                    fprintf( stderr, "Unknown option: [%s]\n", str );
                    printHelpMessage();
                    break;
            } /* switch */
        } else {
            if  ( strcmp( str, "table" ) == 0 ) {
                pInfoMode->fCmdVersion = TRUE;
                pInfoMode->fCmdTable = TRUE;
                continue;
            } 
            if  ( strcmp( str, "stop" ) == 0 ) {
                pInfoMode->fCmdVersion = TRUE; 
                pInfoMode->fNoAutoPlay = TRUE;
                continue;
            } 
            if  ( strcmp( str, "play" ) == 0 ) {
                if  ( isNumeric( strNext ) ) {
                    pInfoMode->startTrack = atoi( strNext );
                    ind++;
                    continue;
                } 
            } 

            printHelpMessage();
            break;
        } /* if */
    }
}


static void      readStatusFast( void ) 
{
    int                sss, dly = 6;
        
    do { 
        sss = cd_status( &cdStatus ) ;
        if (sss == 0 || sss == 4) 
            sleep( 1 );
        dly--;
    }  while  ( sss == 0  ||  sss == 4 );
}


static  void    doCmdCommands( modeInfoType      * pMode )
{
    int             sss;

    /* delay while CD drive initializes itself */
    if ( pMode->fNoFastIn ) { 
        sleep( 6 );
    } else 
        readStatusFast();

    sss = cd_status( &cdStatus ) ;
    if  ( sss == 0  ||  sss == 4 ) {
        fprintf( stderr, "Unable to play cd\n" );
        myExit( -1 );
    }

    cdStatus.cur_track = 1;        
    if  ( pMode->fCmdTable ) 
        printTOC();

    if  ( ! pMode->fNoAutoPlay ) {
        if   ( pMode->startTrack > 0   
               &&  pMode->startTrack <= cdStatus.cur_ntracks + 1 )
            cdStatus.cur_track = pMode->startTrack;
        cd_play( &cdStatus, cdStatus.cur_track, 0, cdStatus.cur_ntracks + 1 );
        if  ( pMode->fCDPlayMode ) 
            myExit( 0 );
    }

    myExit( 0 );
}
  

static  void      readStatusAndDisplay( modeInfoType    * pMode )
{
    int                     dly;
    
    if ( pMode->fNoFastIn ) {
        for (dly = 6; dly > -1; dly--) {
            displayStatusPrintf( &dispInfo,  "wait ... initializing %d ", dly);
            sleep (1);
        }
        displayStatusPrintf( &dispInfo, " " );
    } else {
        displayStatusPrintf( &dispInfo, "Wait... Reading CD Status..." );
        readStatusFast(); 
    }
    displayStatusPrintf( &dispInfo, " " );
/*    sleep( 1 );*/
}


int          main( int argc, char *argv[] )
{
    int                     sss;
    modeInfoType            modeInfo;

    cd_init( &cdStatus );
    readCommandLine( argc, argv, &modeInfo );
    checkCDMounted();
    if  ( modeInfo.fCmdVersion ) 
        doCmdCommands( &modeInfo );

    init_ncurses();
    init_colors();

    memset( &oldcd, 0, sizeof( oldcd ) );
    memset( &cdStatus.thiscd, 0, sizeof( cdStatus.thiscd ) );
    displayInitInfo( &dispInfo, &cdStatus.thiscd );

    /*  display control panel template */
    dispScreen( &modeInfo );

    /* delay while CD drive initializes itself */
    readStatusAndDisplay( &modeInfo );
/*
    init_ncurses();
    init_colors();
    displayInitInfo( &dispInfo, &cdStatus.thiscd );

    for  ( sss = 0; sss < 20; sss++ ) {
        resetterm();
        resetty();
        fixterm();
        displayStatusPrintf( &dispInfo,  "%d", sss );
        refresh();
        move( 0, 0 );
      }
    refresh();
*/  
    sss = cd_status( &cdStatus );
    if (sss == 0 || sss == 4)
        goto done;
    cdStatus.cur_track = 1;

    if  ( ! modeInfo.fNoAutoPlay ) {
        if   ( modeInfo.startTrack > 0   &&  
               modeInfo.startTrack <= cdStatus.cur_ntracks + 1 )
            cdStatus.cur_track = modeInfo.startTrack;
        cd_play( &cdStatus, cdStatus.cur_track, 0, cdStatus.cur_ntracks + 1 );
      }

    /* do cd play loop */
    doPlayLoop( &modeInfo );

done:
    if  ( cdStatus.thiscd.trk != NULL)
        free( cdStatus.thiscd.trk );

    exit_ncurses();

    return( 0 );
}


/*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*
 *
 * cdp.c - end of file
\*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*/
