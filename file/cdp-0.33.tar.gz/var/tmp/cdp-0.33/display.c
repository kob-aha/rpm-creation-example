/*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*
 * display.c -
 *    CD play display functions.   
\*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*/

#include   <stdlib.h>
#include   <stdio.h>
#include   <ncurses.h>
#include   <string.h>

#include   "color.h"
#include   "struct.h"
#include   "misc.h"
#include   "cdp.h"
#include   "hardware.h"
#include   "display.h"
#include   "database.h"
#include   "getline.h"


/*=========================================================================
 * Static Debug Variables
\*=========================================================================*/
/* SOURCE__FILE; */


/*======================================================================
 * Static prototypes
\*======================================================================*/
static  void     refreshMessage( displayInfoType        * pInfo,
				 BOOL                     fRefresh );


/*======================================================================
 * Static constants 
\*======================================================================*/
#define  PANEL_YSIZE          6
#define  PANEL_XSIZE          28
#define  PAD_STARTX           (COLS - PANEL_XSIZE)
#define  TOC_XSIZE            COLS
#define  TOC_YSIZE            ( LINES - 1 )
#define  INFO_LINE            6
#define  TOC_TOP_LINE         7
#define  WIDTH_TRK_NUM        3
#define  WIDTH_TRK_START      9
#define  WIDTH_TRK_LENGTH     7
#define  WIDTH_TRK_NAME       ( TOC_XSIZE - ( WIDTH_TRK_NUM + WIDTH_TRK_START+\
                                WIDTH_TRK_LENGTH ) - 7 )
#define  STARTX_TRK_NUM       1
#define  STARTX_TRK_START     ( STARTX_TRK_NUM + WIDTH_TRK_NUM + 1 )
#define  STARTX_TRK_LENGTH    ( STARTX_TRK_START + WIDTH_TRK_START + 1 )
#define  STARTX_TRK_NAME      ( STARTX_TRK_LENGTH + WIDTH_TRK_LENGTH + 1 )
#define  STARTX_CDNAME        19
#define  WIDTH_CDNAME         ( PAD_STARTX - STARTX_CDNAME )
#define  STARTX_ARTIST        19
#define  WIDTH_ARTIST         ( PAD_STARTX - STARTX_ARTIST )


/*=========================================================================
 * Start of Code
\*=========================================================================*/


/*--------------------------------------------------------------------------
 * output a string that can be made of two colors. ch is used to flip
 * between the two colors.
\*--------------------------------------------------------------------------*/
int   cursesSmartPrint( WINDOW    * pw,
		        int         y,
		        int         x,
		        char      * str, 
		        char        ch, 
		        chtype      regColor,
		        chtype      hiColor )
{
    char            buffer[ 200 ];
    char          * pos;
    BOOL            fRegColor = TRUE;
    char            oldCh;

    strcpy( buffer, str );
    str = buffer;
 
    wmove( pw, y, x );
    wstandend( pw );
    do { 
	pos = strchr( str, ch );
	if  ( pos == NULL ) 
	    pos = str + strlen( str );
	
	oldCh = *pos;
	*pos = 0;
	
	if  ( fRegColor ) { 
	    wattrset( pw, regColor );
	} else {
	    wattrset( pw, hiColor );
	}

	wmove( pw, y, x );
	wprintw( pw, str );
	wstandend( pw );
	x += strlen( str );
	str = pos + 1;
	fRegColor = ! fRegColor;
    }  while  ( oldCh != 0 );

    return  0;
}



#define   BUFFER_SIZE 400

static  void          width_wprintw( WINDOW         * pw,
				     int              y,
				     int              x,
				     int              width,
				     char           * str )
{
    char                   * lpszBuf;
    int                      len;

    lpszBuf = malloc( BUFFER_SIZE );
    if  ( lpszBuf == NULL )
        return;
    len = strlen( str );

    memset( lpszBuf, ' ', BUFFER_SIZE );
    strcpy( lpszBuf + 1, str );
    lpszBuf[ strlen( lpszBuf ) ] = ' ';
    lpszBuf[ width - 1 ] = ' ';
    lpszBuf[ width ] = 0;

    if  ( len > ( width - 2 ) ) 
        lpszBuf[ width - 1 ] = '>';

    mvwprintw( pw, y, x, lpszBuf );
    free( lpszBuf );
}
				    


static  void          displayTrack( displayInfoType * pInfo, 
                                    int               ind )
{
    struct trackinfo   * trk;
    WINDOW             * pwTOC; 
    struct cdinfo      * pCD;
    int                  line, scrLine, startHour;
    char               * lpszSong;

    if  ( ind < pInfo->scrStartTrack  || 
	  pInfo->scrStartTrack + pInfo->cdLines <= ind )
        return;
    line = ind - pInfo->scrStartTrack;

    pwTOC = pInfo->pwTOC;
    pCD = pInfo->pCD;

    if  ( ( ind + 1 ) == pInfo->cur_track  &&  ( ( ind + 1 ) != pInfo->view_track ) )
        wattrset( pwTOC, MARKED_COLOR  |  A_BOLD );
    else
        if  ( ind + 1 == pInfo->view_track ) 
	    wattrset( pwTOC, REVERSE_COLOR );
        else
            wattrset( pwTOC, NORMAL_COLOR );

    trk = &pCD->trk[ ind ];
    
    scrLine = TOC_TOP_LINE + 1 + line;

    /* track number */
    if  ( pInfo->cur_track == ( ind + 1 )  &&  pInfo->fNoFollowMode )
        mvwprintw( pwTOC, scrLine, STARTX_TRK_NUM, "*%2d", ind + 1 );
    else
        mvwprintw( pwTOC, scrLine, STARTX_TRK_NUM, " %2d", ind + 1 );
    
    /* start time */
    startHour = trk->start / (60 * 75 * 60);
    if  ( startHour > 0 ) 
        mvwprintw( pwTOC, scrLine, STARTX_TRK_START,  
                   "%2d:%02d:%02d ", trk->start / (60 * 75 * 60), 
                   trk->start / (60 *75) % 60,
                   ( trk->start / 75 ) % 60 );
    else
        mvwprintw( pwTOC, scrLine, STARTX_TRK_START,  
                   "   %2d:%02d ",  trk->start / (60 *75) % 60,
                   ( trk->start / 75 ) % 60 );
    
    /* length */
    mvwprintw( pwTOC, scrLine, STARTX_TRK_LENGTH, 
               " %2d:%02d ", trk->length / 60, trk->length % 60 ); 
    
/*    if  ( ( ind + 1 ) == pInfo->view_track ) 
        wattrset( pwTOC, REVERSE_COLOR );
    else
        wattrset( pwTOC, NORMAL_COLOR );
*/
    /* name */
    if  ( trk->songname == NULL )
        lpszSong = "";
    else
        lpszSong = trk->songname;
    width_wprintw( pwTOC, scrLine, STARTX_TRK_NAME, WIDTH_TRK_NAME + 2, 
 		   lpszSong );		  

    wattrset( pwTOC, NORMAL_COLOR );
}


static  void          displayEmptyTrack( displayInfoType * pInfo, 
                                         int               ind )
{
    WINDOW             * pwTOC; 
    int                  line, scrLine;

    line = ind - pInfo->scrStartTrack;
    if  ( line >= pInfo->cdLines ) 
        return;

    pwTOC = pInfo->pwTOC;

    wattrset( pwTOC, NORMAL_COLOR );

    scrLine = TOC_TOP_LINE + 1 + line;

    /* track number */
    mvwprintw( pwTOC, scrLine, STARTX_TRK_NUM, "   ", ind + 1 );
    
    /* start time */
    mvwprintw( pwTOC, scrLine, STARTX_TRK_START,  
              "         " );
    /* length */
    mvwprintw( pwTOC, scrLine, STARTX_TRK_LENGTH, "       " );
 
    width_wprintw( pwTOC, scrLine, STARTX_TRK_NAME, WIDTH_TRK_NAME + 2, "" );

    wattrset( pwTOC, NORMAL_COLOR );
}


static  void     whsplitline( WINDOW     * pw, 
                              int          line,
                              int          xSize )
{
    mvwaddch( pw, line, 0, ACS_LTEE );
    mvwaddch( pw, line, xSize - 1, ACS_RTEE );
    wmove( pw, line, 1 ); 
    whline( pw, NORMAL_COLOR | ACS_HLINE, xSize - 2 );
}


static  void        printLabel( WINDOW      * pwTOC, 
			        int           y,
			        int           x,
			        char        * str )
{
    int                      len;

    len = strlen( str );
    mvwaddch( pwTOC, y, x, ACS_RTEE );
    wattrset( pwTOC, NORMAL_COLOR );
    mvwprintw( pwTOC, y, x + 1, " %s", str );
    wstandend( pwTOC );
    wattrset( pwTOC, MARKED_COLOR );
    mvwprintw( pwTOC, y, x + 2 + len, " " );
    wattrset( pwTOC, NORMAL_COLOR );
    mvwaddch( pwTOC, y, x + 3 + len, ACS_LTEE );
}


static void            displayTOC( displayInfoType       * pInfo )
{
    static int           cols_start[] = { STARTX_TRK_START - 1,
                                          STARTX_TRK_LENGTH - 1, 
                                          STARTX_TRK_NAME - 1, 0 };
    int                  ind, currCol, hour;
    WINDOW             * pwTOC; 
    struct cdinfo      * pCD;
    char                 buffer[ 100 ];

    pwTOC = pInfo->pwTOC;
    pCD = pInfo->pCD;

    wstandend( pwTOC );
    wattrset( pwTOC, NORMAL_COLOR );
    werase( pwTOC );

    box( pwTOC, ACS_VLINE, ACS_HLINE );
   
    cursesSmartPrint( pwTOC, 1, 1, " ~A~rtist          : ", '~', NORMAL_COLOR,
		      MARKED_COLOR | A_BOLD );
    cursesSmartPrint( pwTOC, 2, 1, " ~C~D Name         : ", '~', NORMAL_COLOR,
		      MARKED_COLOR | A_BOLD );
    wattrset( pwTOC, NORMAL_COLOR );
    mvwprintw( pwTOC, 3,  1, " Tracks Number   : " );
    mvwprintw( pwTOC, 4,  1, " Total Play Time : " );

    wstandend( pwTOC );
    wattron( pwTOC, MARKED_COLOR | A_BOLD );
    
    width_wprintw( pwTOC, 1, 19, WIDTH_ARTIST, pCD->artist );
    width_wprintw( pwTOC, 2, 19, WIDTH_CDNAME, pCD->cdname );

    sprintf( buffer, "%d ", pCD->ntracks );
    width_wprintw( pwTOC, 3, 19, WIDTH_CDNAME, buffer );
/*    mvwprintw( pwTOC, 3, 20, "%d ", pCD->ntracks ); */

    hour =  pCD->length / 3600;
    if  ( hour > 0 )
        sprintf( buffer, "%d:%02d:%02d ",
               hour, (pCD->length / 60) % 60, pCD->length % 60 );
    else
        sprintf( buffer, "%2d:%02d ",
		 (pCD->length / 60) % 60, pCD->length % 60 );
/*    mvwprintw( pwTOC, 4, 20, buffer ); */
    width_wprintw( pwTOC, 4, 19, WIDTH_CDNAME, buffer );
        
    wattrset( pwTOC, NORMAL_COLOR );

    whsplitline( pwTOC, TOC_TOP_LINE, TOC_XSIZE );
    whsplitline( pwTOC, INFO_LINE - 1, TOC_XSIZE );
    wattrset( pwTOC, NORMAL_COLOR );
    currCol = 1;
    
    for  ( ind = 0; cols_start[ ind  ] != 0; ind++ ) {
        currCol = cols_start[ ind ];
        mvwaddch( pwTOC, TOC_TOP_LINE, currCol, ACS_TTEE );
        mvwaddch( pwTOC, TOC_YSIZE - 1, currCol, ACS_BTEE );
        wmove( pwTOC, TOC_TOP_LINE + 1, currCol );
        wvline( pwTOC, NORMAL_COLOR | ACS_VLINE, TOC_YSIZE - 2 - TOC_TOP_LINE );  
    }
    
    /*----------------------------------------------------------------------
     * We must normalize scrStartTrack
    \*----------------------------------------------------------------------*/
    if  ( ! pInfo->fNoFollowMode )
        pInfo->view_track = pInfo->cur_track;
    if  ( pInfo->view_track > 0 ) {
        if  ( pInfo->scrStartTrack >= pInfo->view_track ) 
            pInfo->scrStartTrack = max( pInfo->view_track - 1 - pInfo->cdLines / 2,
				        0 );

        if  ( pInfo->scrStartTrack + pInfo->cdLines < pInfo->view_track ) 
            pInfo->scrStartTrack = max( pInfo->view_track - 1 - pInfo->cdLines / 2,
				        0 );
    }

    for  ( ind = 0; ind < pCD->ntracks; ind++ ) 
        displayTrack( pInfo, ind );

    for  ( ind = 0; ind < TOC_YSIZE; ind++ ) 
        displayEmptyTrack( pInfo, pCD->ntracks + ind );

    wnoutrefresh( pwTOC );
}


/* display the complete screen */
void      displayControlPanel( displayInfoType       * pInfo )
{
    WINDOW             * pwTOC; 
    struct cdinfo      * pCD;
			      
    pwTOC = pInfo->pwTOC;
    pCD = pInfo->pCD;
    
    displayTOC( pInfo );
  
    mvwprintw( pwTOC, 1, PAD_STARTX + 1, "  STOP     ||       PLAY  " ); 
    mvwprintw( pwTOC, 2, PAD_STARTX + 1, "   <-    RESTART     ->   " ); 
    mvwprintw( pwTOC, 3, PAD_STARTX + 1, "   <<     EJECT      >>   " ); 
    mvwprintw( pwTOC, 4, PAD_STARTX + 1, "  QUIT              HELP  " );
    touchwin( pwTOC ); 
 
    mvwaddch( pwTOC, 0, PAD_STARTX, ACS_TTEE );
    mvwaddch( pwTOC, INFO_LINE - 1, PAD_STARTX, ACS_BTEE );
    wmove( pwTOC, 1, PAD_STARTX );
    wvline( pwTOC, NORMAL_COLOR | ACS_VLINE, INFO_LINE - 2 );  

    printLabel( pwTOC, 0, 2, "CDPlay  " VERSION );   

    if  ( pInfo->fNoFollowMode )
        printLabel( pwTOC, LINES - 2, STARTX_CDNAME +  1 + 4, "Free" );   
    if  ( pInfo->fSilentMode )
        printLabel( pwTOC, LINES - 2, STARTX_CDNAME + 10 + 4, "Silent" );   

    wmove( pwTOC, LINES - 2, 0 );
    wnoutrefresh( pwTOC );
    refreshMessage( pInfo, FALSE );
    doupdate();
}


void      displayInitInfo( displayInfoType       * pInfo,
  			   struct cdinfo         * pCD )
{
    pInfo->pCD = pCD;
    pInfo->scrStartTrack = 0;
    pInfo->cur_track = pInfo->view_track = 0;

    pInfo->pwMessage = newwin( 1, TOC_XSIZE - 2, INFO_LINE, 1 );
    pInfo->pwTOC = newwin( TOC_YSIZE, TOC_XSIZE, 0, 0 );
    if  ( pInfo->pwMessage == NULL  ||  pInfo->pwTOC == NULL  )
        myExit( -1 );

    leaveok( pInfo->pwMessage, TRUE );

    pInfo->fNoFollowMode = FALSE;
    pInfo->cdLines = TOC_YSIZE - TOC_TOP_LINE - 2;
}


static  void     refreshMessage( displayInfoType        * pInfo,
				 BOOL                     fRefresh )
{
    wstandend( pInfo->pwMessage );
    wattron( pInfo->pwMessage, MARKED_COLOR ); /* NORMAL_COLOR ); */   
    werase( pInfo->pwMessage ); 

    wattron( pInfo->pwMessage, MARKED_COLOR );
    cursesSmartPrint( pInfo->pwMessage, 0, 0, pInfo->szMessage, '~', NORMAL_COLOR,
	              MARKED_COLOR | A_BOLD );

    if  ( fRefresh )
        wrefresh( pInfo->pwMessage );
    else
        wnoutrefresh( pInfo->pwMessage );
}


int            displayStatusPrintf( displayInfoType       * pInfo, 
		 		    char                  * fmt, ...)
{
   va_list   argptr;
   int       cnt, ind;
   char      buffer[ TOC_XSIZE + 100 ];
   int       len, pos, count;
   char    * str;

   len = TOC_XSIZE - 2;
   va_start( argptr, fmt );
   buffer[ 0 ] = ' ';
   cnt = vsprintf( buffer + 1, fmt, argptr );
   va_end(argptr);
   
   count = 0;
   str = buffer;
   while  ( *str ) {
       if  ( *str == '~' )
	   count++;
       str++;
   }
   
   len += count;
   pos = strlen( buffer );
   for  ( ind = pos; ind < len; ind++ )
       buffer[ ind ] = ' ';
   buffer[ len ] = 0;

   strcpy( pInfo->szMessage, buffer );
   refreshMessage( pInfo, TRUE );

   return( cnt );
}


void      displayClearScreen( displayInfoType       * pInfo )
{
    /*-----------------------------------------------------------
     * The following is a rather dirty bypass to a bug of ncurses
     * : Ncurses when cleaning screen, uses terminal special code
     * . Thus the screen is automaticly cleaned to current term
     * color. If we want to clear to a specific color. We must 
     * force the terminal into changing it color into the
     * required color 
    \*----------------------------------------------------------*/ 
    if  ( pInfo != NULL ) {
        wstandend( pInfo->pwTOC );
        mvwaddch( pInfo->pwTOC, 0, 0, '.' );
        wrefresh( pInfo->pwTOC );
    }
	    
    standend();
    clear();
/*    clearok( stdscr, TRUE ); */
    move( 0, 0 );
    refresh();
}


void            displayTTYResetColor( displayInfoType       * pInfo )
{
    wstandend( pInfo->pwTOC );
    mvwaddch( pInfo->pwTOC, TOC_YSIZE, TOC_XSIZE, '.' );
    wrefresh( pInfo->pwTOC );
    mvwaddch( pInfo->pwTOC, TOC_YSIZE, TOC_XSIZE, ' ' );
    wmove( pInfo->pwTOC, LINES - 2, 0 );
    wrefresh( pInfo->pwTOC );
}


static void     resetCurrTrackMark( displayInfoType     * pInfo )
{
    int                      track, vTrack;

    track = pInfo->cur_track;
    vTrack = pInfo->view_track;
    pInfo->cur_track = pInfo->view_track = 0;

    displayTrack( pInfo, track - 1 );
    wrefresh( pInfo->pwTOC );

    pInfo->cur_track = track;
    pInfo->view_track = vTrack;
}


#define  SONG_SIZE               502

void      displayEditCurrSongName( cdStatusType         * pStatus,
				   displayInfoType      * pInfo )
{
    char                   * lpszNewName;
    int                      track;
    int                      line, code;
    struct cdinfo          * pCD;

    if   ( pInfo->view_track <= 0 ) 
        return;
    lpszNewName = malloc( SONG_SIZE );
    if  ( lpszNewName == NULL )
        return;

    pCD = pInfo->pCD;
    track = pInfo->view_track;
    resetCurrTrackMark( pInfo );

    displayStatusPrintf( pInfo, pCD->trk[ track - 1 ].songname );
  
    line = TOC_TOP_LINE + 1 + track - 1 - pInfo->scrStartTrack;
    code = getline( line, STARTX_TRK_NAME, WIDTH_TRK_NAME + 2,REVERSE_COLOR,
		    NORMAL_COLOR, MARKED_COLOR | A_BOLD, 
 		    lpszNewName, SONG_SIZE, 
		    pCD->trk[ track - 1 ].songname );

    if   ( code == GETLINE_OK ) {
        free( pCD->trk[ track - 1 ].songname );
        pCD->trk[ track - 1 ].songname = lpszNewName;
	save( pStatus );
    } else { 
        free( lpszNewName );
    }

    displayControlPanel( pInfo );    
}


void      displayEditCDName( cdStatusType         * pStatus,
			     displayInfoType      * pInfo )
{
    char                   * lpszNewName;
    int                      code;
    struct cdinfo          * pCD;

    if   ( pInfo->cur_track <= 0 ) 
        return;
    lpszNewName = malloc( SONG_SIZE + sizeof( pCD->cdname ) );
    if  ( lpszNewName == NULL )
        return;

    resetCurrTrackMark( pInfo );
    pCD = pInfo->pCD;

    code = getline( 2, 19, WIDTH_CDNAME, REVERSE_COLOR,
		    NORMAL_COLOR, MARKED_COLOR | A_BOLD, 
		    lpszNewName, sizeof( pCD->cdname ), 
		    pCD->cdname );

    if   ( code == GETLINE_OK ) {
        strcpy( pCD->cdname, lpszNewName ); 
	save( pStatus );
    } 
    
    free( lpszNewName );
    displayControlPanel( pInfo );    
}


void      displayEditArtistName( cdStatusType         * pStatus,
				 displayInfoType      * pInfo )
{
    char                   * lpszNewName;
    int                      code;
    struct cdinfo          * pCD;

    if   ( pInfo->cur_track <= 0 ) 
        return;
    lpszNewName = malloc( SONG_SIZE + sizeof( pCD->artist ) );
    if  ( lpszNewName == NULL )
        return;

    resetCurrTrackMark( pInfo );
    pCD = pInfo->pCD;

    code = getline( 1, 19, WIDTH_ARTIST,REVERSE_COLOR,
		    NORMAL_COLOR, MARKED_COLOR | A_BOLD, 
		    lpszNewName, sizeof( pCD->artist ), 
		    pCD->artist );

    if   ( code == GETLINE_OK ) {
        strcpy( pCD->artist, lpszNewName ); 
	save( pStatus );
    } 
    
    free( lpszNewName );
    displayControlPanel( pInfo );    
}


/*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*
 *     
 * display.c - End of File
\*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*/
